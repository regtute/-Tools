import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()

value = int(input('输入设置模式(1 设置保存路径)(2 设置快捷键):'))
if value == 1:
    folder_path = filedialog.askdirectory()

    with open('path.ini', mode='w', encoding='utf-8') as f:
        f.write(folder_path.replace('/','\\') + '\\')
elif value == 2:
    key = input('请输入按键(保存后的按键为alt + 你输入的字母):')
    if len(key) > 1:
        print('输入错误')
    else:
        with open('key.ini', mode='w', encoding='utf-8') as f:
            f.write('alt+' + str(key))